package flatten;

import java.util.ArrayList;
import java.util.List;

public class MyFlattenTree<T> implements FlattenTree<T> {
	
	Function<T, T> fLeft;
	Function<Triple<Tree<T>>, T> fRight;
	
	public List<T> flattenInOrder(Tree<T> tree) {
		List<T> outputList = new ArrayList<T>();
		Either<T, Triple<Tree<T>>> either = tree.get();
		if(either.isLeft()){
			//this T below is leaf
			T t= either.ifLeft(fLeft);
			outputList.add(t);
		}
		else {
			Tree.Node<T> t= (Tree.Node<T>)either.ifRight(fRight);
			flattenInOrder(t);
		}
		return outputList;
	}

	
	public static void main(String[] args) {
		
	}
}