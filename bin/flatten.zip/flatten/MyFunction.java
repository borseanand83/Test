/**
 * 
 */
package flatten;

/**
 * @author IBM_ADMIN
 *
 */
public class MyFunction implements Function<Triple<T>, T> {

	@Override
	public T apply(Triple<T> p) {
		// TODO Auto-generated method stub
		return p;
	}

}
